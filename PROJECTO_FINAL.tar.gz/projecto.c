#include "window.h"
#include "Gtk3_CssAux.h"

int main (int argc, char **argv){
  
  gtk_init (&argc, &argv);
  
#if GTK_CHECK_VERSION(3,22,0)
#else
    create_style_from_file ("projecto.css");
#endif


  Main_struct *main_struct;

  main_struct = (Main_struct *)malloc(sizeof(Main_struct));

  main_struct = cria_window();

  g_signal_connect (G_OBJECT(main_struct -> widgets -> window), "destroy", G_CALLBACK(gtk_main_quit), NULL);

  gtk_widget_show_all (main_struct -> widgets -> window);
  gtk_main ();

  return 0;
}
