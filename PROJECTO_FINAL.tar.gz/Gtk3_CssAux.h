#ifndef __GTK3_CSS_AUX_H__
#define __GTK3_CSS_AUX_H__ 1

#include <gtk/gtk.h>

extern void create_style_from_file (gchar *cssFile);

#endif // __GTK3_CSS_AUX_H__
